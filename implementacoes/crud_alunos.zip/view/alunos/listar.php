<?php
    //Incluir o header
    include_once(__DIR__ . "/../include/header.php");
?>

Listagem de Alunos

<?php
    //Incluir o footer
    include_once(__DIR__ . "/../include/footer.php");   
?>
    

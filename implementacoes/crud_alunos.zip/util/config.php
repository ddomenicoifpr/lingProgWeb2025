<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "mysql-server");
define("DB_NAME", "db_alunos");
define("DB_USER", "root");
define("DB_PASSWORD", "root");